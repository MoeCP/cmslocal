tinyMCE.addI18n('en.charcount',{
	desc : 'Count Words And Characters',
	words : 'Words',
	chars : 'Characters (no spaces)',
	chars_with_spaces : 'Characters (with spaces)'
});
