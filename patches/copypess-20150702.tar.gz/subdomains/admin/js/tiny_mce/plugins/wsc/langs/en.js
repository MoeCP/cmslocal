tinyMCE.addI18n('en.wsc',{
WSC_long_name:'WebSpellChecker',
desc:'WebSpellChecker'
});
