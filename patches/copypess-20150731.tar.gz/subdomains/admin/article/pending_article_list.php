<?php
$g_current_path = "article";
require_once('../pre.php');//����������Ϣ
require_once CMS_INC_ROOT.'/Client.class.php';
require_once CMS_INC_ROOT.'/Campaign.class.php';
$logout_folder = '';
if (client_is_loggedin()) {
    $g_current_path = "client_campaign";
    require_once('../client/cms_client_menu.php');
    $logout_folder .= '/client';
} else {
    require_once('../cms_menu.php');
}

require_once CMS_INC_ROOT.'/Client.class.php';
if ((!user_is_loggedin() || User::getPermission() < 1) && !client_is_loggedin()) {
    header("Location: http://".$_SERVER['HTTP_HOST'].$logout_folder."/logout.php");
    exit;
}
require_once CMS_INC_ROOT.'/Article.class.php';

if (!empty($_POST['article_id']) && !empty($_POST['isUpdate'])) {//��ʵ����ֻ������һ�����ж�
    //echo "<pre>";
    //print_r($_POST);
	//���¹�����Ϊ�˷�ֹhackerα�������ύ
    $post_checkbox_array = implode(",", $_POST['isUpdate']);

    $article_id = array();
    foreach ($_POST['isUpdate'] AS $k_isUpdate => $v_isUpdate) {
        $k = $v_isUpdate - 1;
        $article_id = $article_id + array($k_isUpdate => $_POST['article_id'][$k]);
    }

    $p = array();
    $p = array('article_id' => $article_id);
	//echo "<pre>";
	//print_r($p);
    Article::batchApproveArticle($p);
}

$p = array();
$p = $_GET;
$p += array('article_status' => '1gc');

$search = Article::search($p);
if ($search) {
    $smarty->assign('result', $search['result']);
    $smarty->assign('pager', $search['pager']);
    $smarty->assign('total', $search['total']);
    $smarty->assign('count', $search['count']);
}

//echo "<pre>";
//print_r($search);
$g_tag['show_keyword_type']['show_all'] = 'Show all keywords';
$g_tag['show_keyword_type']['show_active'] = 'Show all active keywords';
$g_tag['show_keyword_type']['but_active'] = 'Show all but active keywords';
//O show all keyword under this cp O show only incomplete articles
$campaign_id = $_GET['campaign_id'];
$smarty->assign('campaign_id', $campaign_id);
$smarty->assign('login_permission', User::getPermission());
$smarty->assign('login_role', User::getRole());
$smarty->assign('result_count', count($search['result']));
$smarty->assign('show_keyword_type', $g_tag['show_keyword_type']);
$smarty->assign('feedback', $feedback);
$smarty->assign('startNo', getStartPageNo());
$smarty->display('article/pending_article_list.html');
?>