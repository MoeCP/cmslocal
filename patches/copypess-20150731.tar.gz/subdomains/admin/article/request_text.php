﻿<img src="http://localhost/listmanager/tracks/lead.php?dbupmid="  height="2" width="2" />
<?php
exit("here text");
?>